def not_none(value):
    status = False
    if value is not None:
        status = True
    return status
