number_types = ['exact', 'gte', 'lte', 'in', 'lt', 'gt', 'range']
string_types = ['exact', 'icontains', 'istartswith']
date_types = ['exact', 'gte', 'lte', 'in', 'lt', 'gt', 'range']
